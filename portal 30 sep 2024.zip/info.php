<?php

phpinfo( );

?>